public class WriterSyntax {
    static final String[] writerToken = {"BUFFER_SIZE"};
}
