import ru.spbstu.pipeline.BaseGrammar;

public class ExecutorGrammar extends BaseGrammar {
    ExecutorGrammar(String[] tokens) {
        super(tokens);
    }
}