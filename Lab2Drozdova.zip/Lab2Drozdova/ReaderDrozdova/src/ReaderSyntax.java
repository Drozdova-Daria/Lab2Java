public class ReaderSyntax {
    static final String[] readerToken = {"BUFFER_SIZE"};
}
